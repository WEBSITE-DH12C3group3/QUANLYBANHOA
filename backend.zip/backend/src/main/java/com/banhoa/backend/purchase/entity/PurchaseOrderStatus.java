package com.banhoa.backend.purchase.entity;
public enum PurchaseOrderStatus {
    draft, ordered, received, cancelled
}
