package com.banhoa.backend.common;

public enum Status {
    active,
    inactive,
    banned
}
