// src/environments/environment.prod.ts
export const environment = {
  production: true,
  apiUrl: '/api',  // sau deploy map qua Nginx/Reverse proxy
} as const;
